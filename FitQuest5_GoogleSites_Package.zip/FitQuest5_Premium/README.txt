FITQUEST 5 — PREMIUM SOURCE FILE

Fail:
- index.html: laman perisian kursus interaktif (HTML, CSS dan JavaScript dalam satu fail).

Cara guna:
1. Ekstrak ZIP.
2. Buka index.html dengan Chrome, Edge atau Firefox.
3. Navigasi modul, aktiviti padanan, pemasa, kuiz automatik, refleksi dan kemajuan berfungsi dalam browser.
4. Untuk dimasukkan dalam tugasan Canva, gunakan reka bentuk ini sebagai prototaip digital, bina slaid Canva yang sepadan dan tambah pautan produk selepas laman dihoskan.

Penting:
- Canva bukan editor HTML/JavaScript penuh; kod ini tidak boleh ditampal ke kotak teks Canva untuk terus menjadi laman interaktif.
- Untuk pautan awam dan QR Code, hoskan fail HTML pada platform web yang menyokong HTML (contohnya GitHub Pages atau Netlify), kemudian gunakan URL awam tersebut untuk menjana QR.
- Sahkan Standard Kandungan, Standard Pembelajaran dan prosedur SEGAK daripada DSKP, buku teks dan RPH rasmi yang digunakan.
- Pemasa/stesen ialah alat pembelajaran, bukan pengganti protokol rasmi SEGAK.
